################################################################################
# Lake Volume R Script                                                         #
# Written by: Jeff W. Hollister                                                #
# July/Aug 2009                                                                #
#                                                                              #
# Function to take input bathymetry points an estimate TIN Volume (optional)   #
# and Distance Based Volume                                                    #
# Function requires installed and functioning version of ArcGIS and maptools   #
# rgdal and RPyGeo packages                                                    #
# requires: bathypts of for ID,LONG,LAT,DEPTH                                  #
#           lake polygon shape file (single lake)                              #
#           cell size                                                          #
#           Coordinate Reference System                                        #
# optional: Logical for caluclating TIN Volume from multiple points, and       #
#           Python Path,                                                       #
################################################################################
lrmVolume <- function(bathypts,lakepoly,cell,CRSText,PyPath="C:\\Python25",
                      Dist=T,TIN=F,Cone=F){                           

                   
#Loads required Libraries
require(maptools)
require(rgdal)                                                           
require(RPyGeo)                                   

#Reads in bathymetry points and creates Spatial Points Data Frame
xdf<-read.csv(bathypts)
xcoord<-coordinates(data.frame(xdf[,3],xdf[,4]))  
xspdf<-SpatialPointsDataFrame(xcoord,xdf,
                              proj4string=CRS(CRSText))

MAXDEPTH<-max(xspdf[[5]],na.rm=T)
  
#Read in NH Lakes shapefiles
lakep<-readOGR(lakepoly,gsub(".shp","",lakepoly))
xspdf<-spTransform(xspdf,CRS(proj4string(lakep)))

#Set up rpygeo and R parameters
assign("rpygeo.env",rpygeo.build.env(workspace=getwd(),python.path=PyPath,overwriteoutput=1,
                 mask="lakep",cellsize=cell,extensions="3d"),envir = .GlobalEnv)

#Estimates Lake Volume based on Max and Dist
if(Dist==T){
carea<-cell*cell
rpygeo.geoprocessor("PolygonToLine",
args=list(lakepoly,"xx.shp"))
rpygeo.EucDistance.sa("xx.shp","xxdist","#",cell)
rpygeo.geoprocessor("ExtractByMask_sa",
args=list("xxdist",lakepoly,"xxdist1"))
assign("lakedist",readGDAL("xxdist1"))
MAXDIST<-max(lakedist[["band1"]],na.rm=T)
DistanceVolume<-sum(((lakedist[["band1"]]*MAXDEPTH)/MAXDIST)*carea,na.rm=T)

print(paste("DistanceVolume ",DistanceVolume)) 

}

#This section creates TIN, Add's points and hard lines, calculates and returns volume
if(TIN==T){
SHORE<-0
lakep<-spCbind(lakep,SHORE)
writeOGR(lakep,getwd(),"lakep",driver="ESRI Shapefile")
writeOGR(xspdf,getwd(),"xspdf",driver="ESRI Shapefile")
rpygeo.env$extensions="3d"
rpygeo.geoprocessor("createtin",
args=list("temptin","lakep.shp"),env=rpygeo.env)
argu<-paste("xspdf",".shp DEPTH <none> masspoints true; ","lakep",".shp SHORE <none> hardclip true", sep="")
rpygeo.geoprocessor("edittin",
args=list("temptin", argu),env=rpygeo.env)
unlink("vol.txt")
rpygeo.geoprocessor("SurfaceVolume_3d",
args=list("temptin","vol.txt","ABOVE"),env=rpygeo.env)
xvol<-read.csv("vol.txt")
TINVolume<-xvol[,7]

print(paste("TINVolume ",TINVolume))

}

if(Cone==T){                                                 
ConeVolume<-(lakep[["AREA"]]*MAXDEPTH)/3

print(paste("ConeVolume ", ConeVolume))

}

}

lrmVolume("Partridgemeter.txt","PartridgeLake.shp",10,"+proj=latlong +datum=WGS84",Dist=F,Cone=T,TIN=F)